import { IDisplayController } from '../model/displayController';
declare const envelope: IDisplayController;
export default envelope;
